// Simple interactions for the portfolio. Edit the content in index.html to personalise it.
const root = document.documentElement;
const themeToggle = document.getElementById("themeToggle");
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const readingProgress = document.getElementById("readingProgress");

function updateThemeButton() {
  const dark = root.dataset.theme === "dark";
  themeToggle.textContent = dark ? "☾" : "☼";
  themeToggle.setAttribute("aria-label", dark ? "Switch to light theme" : "Switch to dark theme");
  document.querySelector('meta[name="theme-color"]').content = dark ? "#19171e" : "#f8f5f0";
}
const savedTheme = localStorage.getItem("yuvika-theme");
if (savedTheme === "light" || savedTheme === "dark") root.dataset.theme = savedTheme;
updateThemeButton();

themeToggle.addEventListener("click", () => {
  root.dataset.theme = root.dataset.theme === "light" ? "dark" : "light";
  localStorage.setItem("yuvika-theme", root.dataset.theme);
  updateThemeButton();
});

menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
});
navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

// Filter the project cards by category.
const filters = document.querySelectorAll(".filter");
const projects = document.querySelectorAll(".project-card");
filters.forEach(button => button.addEventListener("click", () => {
  filters.forEach(item => item.classList.toggle("active", item === button));
  const filter = button.dataset.filter;
  projects.forEach(card => {
    card.classList.toggle("hidden", filter !== "all" && card.dataset.category !== filter);
  });
}));

// Signature feature: choose a seed in the Idea Garden to explore an idea.
const ideaSeeds = [
  {
    label: "SEED 01 / TRACKBACK AI",
    title: "What if finding a lost item didn't depend on luck?",
    question: "Could a low-cost connected system help people recover misplaced belongings while keeping privacy and battery life in mind?",
    next: "Map the user journey and test the assumptions before choosing hardware."
  },
  {
    label: "SEED 02 / LEARNING TOOLS",
    title: "What if revision adapted to how you actually learn?",
    question: "Could a small study tool help students spot weak concepts and turn them into short, focused practice sessions?",
    next: "Interview a few students and prototype one simple revision flow."
  },
  {
    label: "SEED 03 / EVERYDAY FRICTION",
    title: "What tiny daily problem deserves a better solution?",
    question: "Could a lightweight app remove one repeated inconvenience without asking people to learn a complicated new system?",
    next: "Keep a one-week friction log, then rank problems by frequency and impact."
  }
];
const seedButtons = document.querySelectorAll(".seed");
seedButtons.forEach(button => button.addEventListener("click", () => {
  const item = ideaSeeds[Number(button.dataset.seed)];
  seedButtons.forEach(seed => seed.classList.toggle("active", seed === button));
  document.getElementById("resultLabel").textContent = item.label;
  document.getElementById("resultTitle").textContent = item.title;
  document.getElementById("resultQuestion").textContent = item.question;
  document.getElementById("resultNext").textContent = item.next;
}));

// Reading progress and active navigation link.
function updateScrollUI() {
  const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
  readingProgress.style.width = `${maxScroll > 0 ? window.scrollY / maxScroll * 100 : 0}%`;
}
window.addEventListener("scroll", updateScrollUI, { passive: true });
updateScrollUI();

const sections = [...document.querySelectorAll("main section[id], main#home")];
if ("IntersectionObserver" in window) {
  const sectionObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const id = entry.target.id || "home";
      navLinks.querySelectorAll("a").forEach(link => {
        link.classList.toggle("active", link.getAttribute("href") === `#${id}`);
      });
    });
  }, { rootMargin: "-35% 0px -55% 0px" });
  sections.forEach(section => sectionObserver.observe(section));
}

// Small entrance animation, with a reduced-motion fallback.
const revealTargets = document.querySelectorAll(".section, .project-card, .skill-row, .now-card, .contact-card");
if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08 });
  revealTargets.forEach(element => {
    element.classList.add("reveal");
    revealObserver.observe(element);
  });
}

// Contact email copy helper.
const emailLink = document.getElementById("emailLink");
document.getElementById("copyEmail").addEventListener("click", async () => {
  const email = emailLink.href.replace("mailto:", "");
  const feedback = document.getElementById("copyFeedback");
  try {
    await navigator.clipboard.writeText(email);
    feedback.textContent = "Email copied.";
  } catch {
    feedback.textContent = `Replace the placeholder email in index.html: ${email}`;
  }
});
document.getElementById("year").textContent = new Date().getFullYear();
